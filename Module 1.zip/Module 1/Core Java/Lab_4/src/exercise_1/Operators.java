package exercise_1;
import java.util.Scanner;

public class Operators {
	int sumOfDigits(int n){
		int r,sum=0;
		while(n>0){
			r=n%10;
			n=n/10;
			sum=sum+(r*r*r);
		}
		return sum;	
	}

	public static void main(String[] args) {
		int n;
		Operators p=new Operators();// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		Scanner s=new Scanner(System.in);
		System.out.println("enter the number");
		n=s.nextInt();
		System.out.println(p.sumOfDigits(n));

	}
}
