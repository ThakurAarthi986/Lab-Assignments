package exercise_5;

import java.util.Scanner;

class InvalidAgeexception extends Throwable 
{
	public InvalidAgeexception(String errorMsg)
	{
		super(errorMsg);
	}
}
public class ValidateAge {
	static void validation(int age) throws InvalidAgeexception
	{
		if(age<15)
			throw new InvalidAgeexception("You are not eligible");
   else  
			System.out.println("You are eligible");
	}
	public static void main(String[] args) throws InvalidAgeexception {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age");
		int age=sc.nextInt();
		ValidateAge.validation(age);
		//System.out.println("Successful");
	}

}
