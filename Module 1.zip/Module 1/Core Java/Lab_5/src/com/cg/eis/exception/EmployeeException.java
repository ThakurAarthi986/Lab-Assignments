package com.cg.eis.exception;

class InvalidSalaryexception extends Throwable 
{
	public InvalidSalaryexception(String errorMsg)
	{
		super(errorMsg);
	}
}
public class EmployeeException {
	static void validation(int salary) throws InvalidSalaryexception
	{
		if(salary<3000)
			throw new InvalidSalaryexception("Your salary is below 3000");
		else
			System.out.println("Your salary is above 3000");
	}
	public static void main(String[] args) throws InvalidSalaryexception {
		EmployeeException.validation(3500);
		
	}

}
