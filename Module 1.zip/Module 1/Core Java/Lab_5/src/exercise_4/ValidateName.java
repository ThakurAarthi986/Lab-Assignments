 package exercise_4;

class InvalidNameexception extends Throwable 
{
	public InvalidNameexception(String errorMsg)
	{
		super(errorMsg);
	}
}

public class ValidateName {
	static void validation(String firstname,String lastname) throws InvalidNameexception
	{
		
		if(firstname.equals("")&&lastname.equals(""))
			throw new InvalidNameexception("Enter valid credentials");	
		else 
			System.out.println("valid user");
	}
	public static void main(String[] args) throws InvalidNameexception{
		System.out.println("Enter your firstname");
		String fname="aa";
		String lname="bb";
		ValidateName.validation(fname, lname);
	}
}
