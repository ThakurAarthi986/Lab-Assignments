package exercise_1;


import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;

public class Q1 {
	public LinkedList<String> getValues() {
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		hm.put(1,"Sunday");
		hm.put(2,"Monday");
		hm.put(3,"Tuesday");
		hm.put(4,"Wednesday");
		hm.put(5,"Thursday");
		hm.put(6,"Friday");
		hm.put(7,"Saturday");
		LinkedList<String> sortedvalues=new LinkedList<String>(hm.values());
		System.out.println(sortedvalues);
		Collections.sort(sortedvalues);
		return sortedvalues;
			}
	public static void main(String[] args) {
			Q1 q=new Q1();
			LinkedList<String> sortedvalues=q.getValues();
			System.out.println(sortedvalues);
		}
	}

