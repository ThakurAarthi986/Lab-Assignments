package exercise_3;

import java.util.ArrayList;
import java.util.HashMap;

public class Q3 {
public HashMap<Integer, Integer> getSquares() {
	int i=0,j=0;int res=0;
	ArrayList<Integer> al=new ArrayList<Integer>();
	int[] arr= {2,4,5,8};
	for(i=0;i<arr.length;i++) {
		res=arr[i]*arr[i];
	//for(j=0;j<arr.length;j++)
	al.add(res);
	}
	System.out.println(al);
	HashMap<Integer,Integer> hm = new HashMap<Integer,Integer>();
	hm.put(arr[0], al.get(0));
	hm.put(arr[1], al.get(1));
	hm.put(arr[2], al.get(2));
	hm.put(arr[3], al.get(3));
	//System.out.println(hm);
	return hm;
}
public static void main(String[] args) {
	Q3 q=new Q3();
	//q.getSquares();
	HashMap<Integer,Integer> hm = q.getSquares();
		System.out.println(hm);
}
}
