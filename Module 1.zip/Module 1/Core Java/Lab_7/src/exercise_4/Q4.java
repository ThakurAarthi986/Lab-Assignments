package exercise_4;

import java.util.HashMap;

public class Q4 {
public HashMap<Integer, String> getStudents() {
	int[] stud= {1,2,3}; int i=0;
	String s1 = null,s2 = null,s3 = null;
	int[] marks= {75,85,90};
	for(i=0;i<marks.length;i++) {
		if(marks[i]>=90)
			 s1 = stud[i] +" " + "is eligible for gold medal";
		else if(marks[i]>=80 && marks[i]<90)
			s2= stud[i] +" " + "is eligible for silver medal";
		else if(marks[i]>=70 && marks[i]<80)
			s3= stud[i] +" " + "is eligible for bronze medal";
		else
			break;
	}
	HashMap<Integer, String> hm=new HashMap<Integer, String>();
	hm.put(marks[0],s1);
	hm.put(marks[1],s2);
	hm.put(marks[2],s3);
		return hm;
		}
public static void main(String[] args) {
	Q4 q=new Q4();
	//HashMap<Integer, String> hm=new HashMap<Integer, String>();
	//hm.put(marks[i],q.getStudents());
	HashMap<Integer, String> hm=q.getStudents();
	System.out.println(hm);

}
}
