	package exercise_2;
	
	import java.util.LinkedHashMap;
	
	public class Q2 {
	
		public static void main(String[] args) {
			int i = 0, j = 0;
			int[] count=new int[10];
					char[] ch = { 'a', 'b', 'a', 'a' };
			for (i = 0; i < ch.length; i++) {
				count[i]=1;
				for (j = i + 1; j < ch.length; j++) {
					if (ch[i] == ch[j]) {
			            					count[i]++;
						                    ch[j]='0';
					}
			}
	}
			for(i=0;i<ch.length;i++) {
			                           if(ch[i]!='0')
				                         System.out.println("the occurance of" + " " + ch[i] + "  "+ "is:" +count[i]);
			}
					 
			LinkedHashMap<Character, Integer> map=new LinkedHashMap<Character, Integer>();
			 map.put(ch[0],count[0]);
			 map.put(ch[1],count[1]);
			 map.put(ch[2],count[2]);
			 map.put(ch[3],count[3]);
			 System.out.println(map);
			 	}
	}
