package com.cg.eis.dao;

import org.junit.Assert;
import org.junit.Test;

import com.cg.eis.bean.Employee;

public class Testing {
    DaoClass dao =new DaoClass();
//    @Test
//    public void getInfo() {
//        Employee e1=new Employee(1,"AARTHI",99999,"CEO");//expected
//        Employee e9=dao.selectData(1);
//        Assert.assertEquals(e1,e9);
//    }
    @Test
    public void getInfo2() {
        boolean b=dao.removeData(99);
        boolean b1 =true;
        Assert.assertEquals(b1,b);

    }
    @Test
    public void getInfo1() {
        boolean b=dao.removeData(5);
        boolean b1 =true;
        Assert.assertEquals(b1,b);

    }
}
