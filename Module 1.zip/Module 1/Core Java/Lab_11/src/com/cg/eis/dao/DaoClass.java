package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.eis.bean.Employee;

public class DaoClass implements DaoInterface {
	static HashMap<Integer, Employee> h = new HashMap<Integer, Employee>();
	public DaoClass()
	{
		Employee e1=new Employee(1,"MANI",99999,"CEO");
		h.put(e1.getId(),e1);
		Employee e2=new Employee(2,"SIRI",99999,"CEO");
		h.put(e2.getId(),e2);
		Employee e3=new Employee(3,"Nani",9000,"CEO");
		h.put(e3.getId(),e3);
		Employee e4=new Employee(4,"Stupid",10000,"peon");
		h.put(e4.getId(),e4);
		Employee e5=new Employee(5,"Idiot",10000,"Clerk");
		h.put(e5.getId(),e5);
	}
	public void add(Employee e) {
		// TODO Auto-generated method stub
		h.put(e.getId(), e);
		System.out.println("successfully added");
		System.out.println(h.get(e.getId()));
	}

	public Employee selectData(int nid) {
		return h.get(nid);
	}

	public void getAllData() {
		// TODO Auto-generated method stub
		Set set = h.entrySet();
		Iterator i = set.iterator();
		System.out.println("EID\tNAME\tSALARY\tDESIGNATION");
		while (i.hasNext()) {
			Entry entry = (Entry) i.next();
			// int i1 = (Integer) entry.getKey();
			// if (i1 == id) {
			// b=true;
			//System.out.print(entry.getKey() + "\t");
			System.out.println(entry.getValue());
			//System.out.println(h);
		}
	}
	public boolean removeData(int id) {
		// TODO Auto-generated method stub
		if(h.remove(id)!=null)
			return true;
		else
			return false;
	}
}
