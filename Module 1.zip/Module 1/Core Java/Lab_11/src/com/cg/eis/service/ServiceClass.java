package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.DaoClass;

public class ServiceClass implements ServiceInterface {
	static DaoClass d = new DaoClass();

	public void addValues(int id, String name, int salary, String designation) {
		// TODO Auto-generated method stub
		Employee e = new Employee(id, name, salary, designation);

		d.add(e);
	}

	public Employee selectData(int nid) {
		// TODO Auto-generated method stub
		System.out.println(" in service class");
		return d.selectData(nid);
	}

	public void getAllData() {

		d.getAllData();
	}

	public boolean removeData(int id) {
		// TODO Auto-generated method stub
 return d.removeData(id);		
	}

}
