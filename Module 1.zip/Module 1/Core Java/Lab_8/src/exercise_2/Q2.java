package exercise_2;

import java.util.*;
// Using thread class
 class task implements Runnable
 {
	 public void run()
	 {
		 while(true)
		 {
			 System.out.println(new Date());
			 try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		 }
	 }
 }
 public class Q2
 {
	 public static void main(String args[])
	 {
		 task t1=new task();
		 Thread t=new Thread(t1);
		 t.start();
	 }
 }
// Using Timer class and TimerTask class
 /*
 class Task extends TimerTask implements Runnable{
 	   public void run() {
 		   Calendar c=new GregorianCalendar();
 	      System.out.println("[" + c.getTime() + "]");
 	   }
 }

 public class Timertask {
 	   public static void main(String []args) {
 	      Task t1 = new Task();
 	      Timer t = new Timer();
 	      //t.schedule(t1,0,10000);
 	      t.scheduleAtFixedRate(t1, 0, 10000);
 	   }
 }*/