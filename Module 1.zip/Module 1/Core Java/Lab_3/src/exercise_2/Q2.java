package exercise_2;
import java.util.Scanner;

public class Q2 {
	String[] method(String[] s1) {
		int i, j;
		String c;
		for (i = 0; i < s1.length; i++) {
			for (j = i + 1; j < s1.length; j++) {
				if (s1[i].compareTo(s1[j])>0) {
					c = s1[i];
					s1[i] = s1[j];
					s1[j] = c;
				}
			}
		}
		//for(i=0;i<s1.length;i++)
			///System.out.println(s1[i]);
		for(i=0;i<s1.length;i++)
			{
			if(i<(s1.length)/2) 
					s1[i]=s1[i].toUpperCase();
			else
				s1[i]=s1[i].toLowerCase();
			}
		if(s1.length%2==1)
			s1[(s1.length/2)]=s1[(s1.length/2)].toUpperCase();
		return s1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int k;
		Q2 p = new Q2();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter n");
		int n = s.nextInt();
		String[] s1 = new String[n];
		System.out.println("Enter Strings");
		for (k = 0; k < n; k++) {
			s1[k] = s.next();
			//s1[k]=s.next();
		}
		s1=p.method(s1);
		for(k=0;k<s1.length;k++)
			System.out.println(s1[k]);
		s.close();
	}

}
