package exercise_1;
import java.util.Scanner;

public class Q1 {

	int getSecondSmallest(int a[]) {
		int i, j, c;
		for (i = 0; i < a.length; i++)
			for (j = i + 1; j < a.length; j++)
				if (a[i] > a[j]) {
					c = a[i];
					a[i] = a[j];
					a[j] = c;
				}
		return a[1];
	}

	public static void main(String[] args) {
		int k;
		Q1 ob = new Q1();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size n");
		int n = s.nextInt();
		int[] a = new int[n];
		System.out.println("Enter array elements");
		for (k = 0; k < n; k++)
			a[k] = s.nextInt();
		System.out.println(ob.getSecondSmallest(a));
		s.close();
	}
}
