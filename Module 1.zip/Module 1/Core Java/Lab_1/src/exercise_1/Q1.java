package exercise_1;

import java.util.Scanner;

public class Q1 {
    public int calculateSum(int n)
    {
    	int sum=0,i;
    	for(i=1;i<=n;i++)
    	{
    		if(i%3==0||i%5==0)
    			sum=sum+i;
    	}
    	return sum;
   }
    public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Q1 q=new Q1();
		int sum=q.calculateSum(n);
		//System.out.println("sum="+sum);
	}
}
