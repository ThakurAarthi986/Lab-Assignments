package exercise_2;

import java.util.Scanner;

public class Q2 {
	public int calculateDifference(int n) {
	int sum=0,i,s,s1;
	for(i=0;i<=n;i++)
	{
		s=((n*(n+1)*(2*n+1))/6);
		s1=((n*(n+1))/2);
		sum=s-s1;
	}
	return sum;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	Q2 q=new Q2();
	int diff=q.calculateDifference(n);
    System.out.println("difference="+diff);
    }
}