
package exercise_4;

import java.util.Scanner;

public class Q4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Q4 q=new Q4();
		  System.out.println(q.checkNumber(n));
	}
		 
		 public boolean checkNumber(int n){
		  if(n<=0)
		  {
		   return false;
		  }
		   
		  while(n > 1){
		   if(n % 2 != 0)
		    return false;
		   n = n/ 2;
		  }
		  return true;
		 }
		 
		}
