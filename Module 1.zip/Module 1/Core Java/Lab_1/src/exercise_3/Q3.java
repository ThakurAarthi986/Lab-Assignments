package exercise_3;

import java.util.Scanner;

public class Q3 {
	public boolean checkNumber(int number)
	{
		int a,b,flag=0;
		while(number>0)
		{
			a=number%10;
			number=number/10;
			b=number%10;
			if(a>b)
				flag=flag+1;
			    break;
		}
		if(flag==0)
			return false;
		else 
			return true;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Q3 q=new Q3();
		boolean num=q.checkNumber(n);
		System.out.println("num="+num);
		
	}
	}

