package exercise_1;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Q1 {

	public static void main(String[] args) {
		System.out.println("enter the numbers");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		StringTokenizer st=new StringTokenizer(s);
		int b=0,c=0;
		while(st.hasMoreTokens()){
			String a=st.nextToken();
			c=Integer.parseInt(a);
			System.out.println(c);
			b+=Integer.parseInt(a);
		}
		System.out.println("sum is:"+b);

	}

}
