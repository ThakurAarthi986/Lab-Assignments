package com.cg.eis.service;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.eis.bean.EmployeeBean;
import com.cg.eis.dao.EmployeeDAO;

public class EmployeeService implements EmployeeServicel {

	public int addEmployee(int empId, String empDesg, String empName, float empSal) {
		String scheme = "";
		if (empSal > 5000 && empSal < 20000)
			scheme = "Scheme C";
		else if (empSal >= 20000 && empSal < 40000)
			scheme = "Scheme B";
		else if (empSal >= 40000)
			scheme = "Scheme A";
		else
			scheme = "No Scheme";
		EmployeeDAO employeeDAO = new EmployeeDAO();
		EmployeeBean empBean = new EmployeeBean();
		empBean.setEmpId(empId);
		empBean.setEmpName(empName);
		empBean.setEmpDesg(empDesg);
		empBean.setEmpSal(empSal);
		empBean.setScheme(scheme);
		int updateResult = 0;
		try {
			updateResult = employeeDAO.addEmployee(empBean);
			return updateResult;
		} catch (Exception ex) {
			System.out.println(ex.toString());
			return 0;
		}
	}

	public int addEmployee(EmployeeBean employeeBean) {
		return 0;
	}

	public ArrayList getEmployeeDetailsById(int empId) throws Exception {
		return null;
	}

	public int addEmployee1(int empId, String empDesg, String empName, float empSal) {
		return 0;
	}

	public ResultSet searchEmployee(int empId) {
		EmployeeDAO employeeDAO = new EmployeeDAO();
		EmployeeBean empBean = new EmployeeBean();
		empBean.getEmpId();
		ResultSet empResult;
		try {
			empResult = employeeDAO.searchEmployee(empId);
			return empResult;
		} catch (Exception ex) {
			System.out.println(ex.toString());
			return null;
		}
	}

	// TODO Auto-generated method stub
	public int updateEmployee(int empId) {
		EmployeeDAO employeeDAO = new EmployeeDAO();
		EmployeeBean empBean = new EmployeeBean();
		empBean.getEmpId();
		int update;
		try {
			update = employeeDAO.updateEmployee(empId);
			return update;
		} catch (Exception ex) {
			System.out.println(ex.toString());
			return 0;
		}

	}

	public ResultSet showEmployee() {
		EmployeeDAO employeeDAO = new EmployeeDAO();
		EmployeeBean empBean = new EmployeeBean();
		ResultSet show;
		try {
			show = employeeDAO.showEmployee();
			return show;
		} catch (Exception ex) {
			System.out.println(ex.toString());
			return null;
		}
	}

	public int deleteEmployee(int empId) {
		EmployeeDAO employeeDAO = new EmployeeDAO();
		EmployeeBean empBean = new EmployeeBean();
		empBean.getEmpId();
		int delete;
		try {
			delete = employeeDAO.deleteEmployee(empId);
			return delete;
		} catch (Exception ex) {
			System.out.println(ex.toString());
			return 0;
		}

	}
}
