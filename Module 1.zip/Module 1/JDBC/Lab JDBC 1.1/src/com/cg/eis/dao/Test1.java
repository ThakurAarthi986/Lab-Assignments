package com.cg.eis.dao;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import org.junit.Test;

import com.cg.eis.bean.EmployeeBean;

public class Test1 {

	/*@Test
	public void addEmployee() {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = EmployeeDB.getConnection1();
			System.out.println(con);
			String ins_str = "insert into employee values(?,?,?,?,?)";
			pstmt = con.prepareStatement(ins_str);
			pstmt.setInt(1, 123);
			pstmt.setString(2, "mv");
			pstmt.setString(3, "ab");
			pstmt.setString(4, "cd");
			pstmt.setFloat(5, 1000);
			Integer updateCount = pstmt.executeUpdate();
			System.out.println(updateCount);
			Integer expected=1;
			assertEquals(expected,updateCount);
			con.close();
			//return updateCount;
		} catch (Exception ex) {
			System.out.println(ex);
			
		}
	}*/

	@Test
	public void updateEmployee() throws Exception {
		Connection con = null;
		PreparedStatement pstmt = null;
		con = EmployeeDB.getConnection1();
		String ins_str = "update employee set empName=? where empId=?";
		pstmt = con.prepareStatement(ins_str);
		pstmt.setString(1, "hijk");
		pstmt.setInt(2, 123);
		int update = pstmt.executeUpdate();
		int update1 = 0;
		assertSame(update, update1);

	}
}
