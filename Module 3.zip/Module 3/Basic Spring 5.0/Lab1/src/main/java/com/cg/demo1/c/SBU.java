package com.cg.demo1.c;

import java.util.List;

public class SBU {
private int sbuCode;
private String sbuName;
private String sbuHead;
private List<Employee> emplist;
public int getSbuCode() {
	return sbuCode;
}
public void setSbuCode(int sbuCode) {
	this.sbuCode = sbuCode;
}
public String getSbuName() {
	return sbuName;
}
public void setSbuName(String sbuName) {
	this.sbuName = sbuName;
}
public String getSbuHead() {
	return sbuHead;
}
public void setSbuHead(String sbuHead) {
	this.sbuHead = sbuHead;
}
public List<Employee> getEmplist() {
	return emplist;
}
public void setEmplist(List<Employee> emplist) {
	this.emplist = emplist;
}
}
