package com.cap.anurag.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cap.anurag.entities.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void deleteEmployeeById(Integer id) throws RecordNotFoundException {
		Employee employee = entityManager.find(Employee.class, id);
		entityManager.remove(employee);

	}
}
